<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\EjemplaresModel;
use App\Models\LibrosModel;
use App\Models\OpinionesModel;
use App\Models\PrestamosModel;
use App\Models\RegresosModel;
use App\Models\ReservasModel;
use PharIo\Manifest\Library;

class LibrosController extends BaseController
{
    public function borrar_libro()
    {
        $model = new LibrosModel();
        $datos = $this->request->getVar();
        $model->borrar_libro($datos['id_libro']);

        return redirect()->to(base_url('usuarios/privado/2/gestion_libros'));
    }

    //OPCION: EJEMPLAR AÑADIR INDIVIDUAL
    public function gestion_ejemplares(){
        $model = new LibrosModel();
        $model_ejemplar = new EjemplaresModel();

        $datos = [
            'libros'=> $model->obtener_libro(),
            'ejemplares' =>$model_ejemplar->obtener_ejemplar()
        ];
        return view('privada_responsable/opcion_gestion_ejemplar',$datos);
    }

    public function agregar_ejemplar(){
        $model_ejemplar = new EjemplaresModel();
        
        $datos = $this->request->getVar();
        
        $data = [
            'id_libro' => $datos['id_libro']
        ];
        $model_ejemplar->save($data);

        return redirect()->to(base_url('usuarios/privado/2/gestion_ejemplares'));
    }

    public function borrar_ejemplar(){
        $model = new EjemplaresModel();

        $datos = $this->request->getVar();
        $model->borrar_ejemplar($datos['id_ejemplar']);

        return redirect()->to(base_url('usuarios/privado/2/gestion_ejemplares'));
    }

    public function reservar(){
        $model = new ReservasModel();

        $datos = $this->request->getVar();
        $data = [
            'id_ejemplar'=>$datos['id_ejemplar'],
            'id_usuario' => $datos['id_usuario']
        ];
        $model->insertar_reservar($data);

        return redirect()->to(base_url('usuarios/privado/'.session()->get('rol').'/catalogo'));
    }

    public function reserva_aceptada(){
        //SE HARÁ EL INSERT EN LAS 3 TABLAS, SI EL USUARIO SE ATRASA YA SE ACTUALIZARÁ LA INFORMACIÓN
        //LA FECHA INICIO SERÁ IGUAL A LA FECHA BUSQUEDA, QUE AL MISMO TIEMPO LA FECHA DEVOLUCIÓN PARTIRÁ DE ESTA FECHA, 15 DÍAS DESPUÉS DE FECHA INICIO
        //SI EL USUARIO LO RECOGE DÍAS MÁS TARDE A LA FECHA ENTREGA, SE ACTUALIZARÁ LA FECHA BUSQUEDA Y FECHA DEVOLUCIÓN (+) FECHA ENTREGA LIBRO DE 'tbl_reservas' 
        //AL IGUAL QUE FECHA INICIO Y FECHA DEVOLUCION DE 'tbl_prestamos'
        //AL IGUAL QUE FECHA DEVOLUCION DE 'tbl_regresos'
        
        $model = new ReservasModel();
        $model_prestamo = new PrestamosModel();
        $model_regreso = new RegresosModel();
        
        $datos = $this->request->getVar();

        $fecha_devolucion = date_create($datos['fecha_busqueda']);
        date_add($fecha_devolucion, date_interval_create_from_date_string("15 days"));
        $fecha_devolucion = date_format($fecha_devolucion,"Y-m-d");

        $data = [
            'fecha_busqueda' => $datos['fecha_busqueda'],
            //'fecha_devolucion' => $fecha_devolucion
        ];
        $model->actualizar_reserva($datos['id_reserva'],$data);

        $data = [
            'id_ejemplar'=>$datos['id_ejemplar'],
            'id_usuario'=>$datos['id_usuario'],
            //'fecha_inicio'=>$datos['id_usuario'],
        ];
        //$model_prestamo->insertar_prestamo($data);

        $data = [
            'id_usuario' => $datos['id_usuario'],
            'id_ejemplar' =>  $datos['id_ejemplar']
        ];
        //$model_regreso->insertar_regreso($data);
        return redirect()->to(base_url('usuarios/privado/'.session()->get('rol').'/reservas'));
    }

    public function recogido(){

        $model = new ReservasModel();
        $model_prestamo = new PrestamosModel();
        $model_regreso = new RegresosModel();

        $datos = $this->request->getVar();
        $fecha_entrega_libro = date('Y-m-d');
        $fecha_devolucion = $fecha_entrega_libro;
        $fecha_devolucion= date("Y-m-d",strtotime($fecha_devolucion."+ 15 days")); 
        
        $data = [
            'fecha_devolucion'=>$fecha_devolucion,
            'fecha_entrega_libro'=>$fecha_entrega_libro,
        ];
        $model->actualizar_reserva($datos['id_reserva'],$data);
        
        $data = [
            'id_ejemplar'=>$datos['id_ejemplar'],
            'id_usuario'=>session()->get('id_usuario'),
            'fecha_inicio'=>$fecha_entrega_libro,
            'fecha_devolucion'=>$fecha_devolucion,
        ];
        $model_prestamo->insertar_prestamo($data);

        $data = [
            'id_ejemplar'=>$datos['id_ejemplar'],
            'id_usuario'=>session()->get('id_usuario'),
            'fecha_devolucion'=>$fecha_devolucion
        ];
        //$model_regreso->insertar_regreso($data);        
        
        return redirect()->to(base_url('usuarios/privado/'.session()->get('rol')));
    }

    public function historial_reservas(){
        $model = new LibrosModel();
        $model_ejemplar = new EjemplaresModel();
        $model_reserva = new ReservasModel();

        $datos = [
            'libros'=> $model->obtener_libro(),
            'ejemplares' =>$model_ejemplar->obtener_ejemplar(),
            'reservas'=>$model_reserva->obtener_reserva()
        ];
        return view('privada_usuario/historial_reservas',$datos);
    }

    public function reservas(){
        $model = new LibrosModel();
        $model_ejemplar = new EjemplaresModel();
        $model_reserva = new ReservasModel();

        $datos = [
            'libros'=> $model->obtener_libro(),
            'ejemplares' =>$model_ejemplar->obtener_ejemplar(),
            'reservas'=>$model_reserva->obtener_reserva()
        ];
        return view('privada_responsable/reservas',$datos);
    }

    public function formulario_opinion(){
        $datos = $this->request->getVar();
        
        $model = new LibrosModel();
        $data['libros']=$model->obtener_libro($datos['id_libro']);
        return view('privada_usuario/formulario_opinion',$data);
    }

    public function opinar(){
        $model = new OpinionesModel();

        $datos = $this->request->getVar();
        $data = [
            'id_libro'=> $datos['id_libro'],
            'id_usuario'=>session()->get('id_usuario'),
            'opinion'=>$datos['opinion']
        ];
        $model->insertar_opinion($data);
        return redirect()->to(base_url('usuarios/privado/'.session()->get('rol')));
    }

    public function devolver(){
        $model = new RegresosModel();
        $model_prestamo = new PrestamosModel();

        $datos = $this->request->getVar();
        dd($datos);
        $fecha_devolucion = date('Y-m-d');
        $data = [
            'id_usuario'=>session()->get('id_usuario'),
            'id_ejemplar'=>$datos['id_ejemplar'],
            'fecha_devolucion'=>$fecha_devolucion
        ];
        $model->insertar_regreso($data);
        return redirect()->to('usuarios/privado/'.session()->get('rol'));
    }
}
