<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\AutoresModel;
use App\Models\BibliotecasModel;
use App\Models\EjemplaresModel;
use App\Models\LibroAutorModel;
use App\Models\LibrosModel;
use App\Models\RolesModel;
use App\Models\UsuariosModel;

class GeneralController extends BaseController
{
    public function pagina_principal()
    {
        $model = new BibliotecasModel();

        $biblioteca = $model->obtener_biblioteca(1);
        $datos = [
            'nombre_biblioteca'=>$biblioteca['nombre_biblioteca'],
            'imagen' =>$biblioteca['imagen'],
            'telefono' => $biblioteca['telefono'],
            'direccion' => $biblioteca['direccion'],
            'provincia' => $biblioteca['provincia'],
            'descripcion' => $biblioteca['descripcion'],
            'tipo' => $biblioteca['tipo'],
            'construccion' => $biblioteca['construccion'],
            'horario_manana_l_m' => $biblioteca['horario_manana_l_m'],
            'horario_tarde_l_m' => $biblioteca['horario_tarde_l_m'],
            'horario_manana_j' => $biblioteca['horario_manana_j'],
            'horario_manana_v' => $biblioteca['horario_manana_v']
        ];
        return view('principal/pagina_principal',$datos);
    }
    public function catalogo(){
        return view('principal/catalogo');
    }

    public function busqueda_simple(){

        $model = new LibrosModel();

        $datos = $this->request->getGet();
        if (isset($datos) && isset($datos['titulo'])) {
            $titulo = $datos['titulo'];
            $data['texto'] = $datos['titulo'];
            $libros = $model->libro_titulo($datos['titulo']);
            //dd($data);
        } else {
            $titulo = "";
            $libros = $model->obtener_libro();
        }

        /*************** TABLE GENERATOR ********************/
        $table = new \CodeIgniter\View\Table();

        /*************** TABLE GENERATOR ********************/
        $data = [
            'libros' => $libros,
            'titulo' => $titulo,
            'table' => $table,
        ];
        
        return view('principal/busqueda_simple',$data);

    }

    public function busqueda_avanzada(){

        $datos = $this->request->getVar(); 
        if ( $datos == null ) return view('principal/busqueda_avanzada');
        elseif ( $datos != null ) {

            
            $model_ejemplar = new EjemplaresModel();
            $ejemplares = $model_ejemplar->busqueda_avanzada($datos['titulo'],$datos['autor'],$datos['categoria']);

            $data = [
                'ejemplares'=>$ejemplares,
            ];
            return view('principal/busqueda_avanzada',$data);
        } 
    }
    public function horarios(){
        $model = new UsuariosModel();
        //$model_rol = new RolesModel();
        $model_biblioteca = new BibliotecasModel();
        
        $data['biblioteca'] = $model_biblioteca->obtener_biblioteca(1);
        $data['usuarios'] = $model->obtener_responsables();
        //$data['usuarios']=$model->obtener_usuario();
        return view('principal/horarios',$data);
    }
    public function sobre_nosotros(){
        return view('principal/sobre_nosotros');
    }
}
