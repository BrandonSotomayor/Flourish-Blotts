<?= $this->extend('layouts/privado_usuario') ?>

<?= $this->section('historial_reservas') ?>

    <div class="container">
        <div class="row" style="margin-top: 20px;">
            <div class="col"></div>
            <div class="col" style="text-align: center;">
            <div class="col"></div>
        </div>
        <div class="row" style="text-align: center;">
            <h3>Reservas</h3>
            <div class="col-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ISBN-13</th>
                            <th scope="col">Título</th>
                            <th scope="col">QR</th>
                            <th>Estado</th>
                        </tr>
                    </thead>

                    <?php if (! empty($libros) && is_array($libros)): ?>
                        
                        <?php foreach ($libros as $libro): ?>

                            <tbody>
                                <tr>
                                <?php if (! empty($ejemplares) && is_array($ejemplares)): ?>
                        
                                    <?php foreach ($ejemplares as $ejemplar): ?>

                                        <?php foreach ($reservas as $reserva): ?>

                                            <?php if ( $reserva['id_ejemplar'] == $ejemplar['id_ejemplar'] && $reserva['fecha_busqueda'] == null && $reserva['id_usuario'] == session()->get('id_usuario') ) { ?>
                                                <tbody>
                                                    <tr>
                                                        <td><?= $libro['isbn_13'] ?></td>
                                                        <td><?= $libro['titulo'] ?></td>
                                                        <?php if ( $libro['id_libro'] == $ejemplar['id_libro'] && $ejemplar['id_ejemplar'] < 10 ){ ?>
                                                            <td><?= $libro['isbn_13']."-0".$ejemplar['id_ejemplar'] ?></td>
                                                        <?php } ?>
                                                        <?php if ( $libro['id_libro'] == $ejemplar['id_libro'] && $ejemplar['id_ejemplar'] >= 10 ){ ?>
                                                            <td><?= $libro['isbn_13']."-".$ejemplar['id_ejemplar'] ?></td>
                                                        <?php } ?>
                                                        <td>Pendiente</td>
                                                    </tr>
                                                </tbody>
                                            <?php } ?>
                                            <?php if ( $reserva['id_ejemplar'] == $ejemplar['id_ejemplar'] && $reserva['fecha_busqueda'] != null && $reserva['id_usuario'] == session()->get('id_usuario') ) { ?>
                                                <tbody>
                                                    <tr>
                                                        <td><?= $libro['isbn_13'] ?></td>
                                                        <td><?= $libro['titulo'] ?></td>
                                                        <?php if ( $libro['id_libro'] == $ejemplar['id_libro'] && $ejemplar['id_ejemplar'] < 10 ){ ?>
                                                            <td><?= $libro['isbn_13']."-0".$ejemplar['id_ejemplar'] ?></td>
                                                        <?php } ?>
                                                        <?php if ( $libro['id_libro'] == $ejemplar['id_libro'] && $ejemplar['id_ejemplar'] >= 10 ){ ?>
                                                            <td><?= $libro['isbn_13']."-".$ejemplar['id_ejemplar'] ?></td>
                                                        <?php } ?>
                                                        <td>En curso/finalizado</td>
                                                    </tr>
                                                </tbody>
                                            <?php } ?>
                                        <?php endforeach ?>
                                    <?php endforeach ?>
                            </table>
                                <?php endif ?>
                                </tr>
                            </tbody>
                        <?php endforeach ?>
                </table>
                    <?php endif ?>
            </div>
        </div>
    </div>


<?= $this->endSection() ?>