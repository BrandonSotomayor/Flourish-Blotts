<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flourish & Blotts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>

    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-1"></div>
            <div class="col bg-dark text-light"><h1>Flourish & Blotts</h1></div>
        </div>
    </div>
    <div class="row bg-secondary">
        <div class="col-1"></div>
         <div class="col-5">
            <a href="<?= base_url('usuarios/privado/'.session()->get('rol')) ?>" class="btn btn-secondary">Inicio</a>
            <a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/gestion_libros') ?>" class="btn btn-secondary">Libros</a>
            <a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/gestion_ejemplares') ?>" class="btn btn-secondary">Ejemplares</a>
            <a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/gestion_usuarios') ?>" class="btn btn-secondary">Usuarios</a>
            <a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/reservas') ?>" class="btn btn-secondary">Reservas</a>
        </div>
        <div class="col-3"></div>
        <div class="col-2">
            <a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/mi_cuenta').'?id_usuario='.session()->get('id_usuario') ?>" class="btn btn-secondary">Mi Cuenta</a>
            <a href="<?= base_url('usuarios/cerrar_sesion') ?>" class="btn btn-dark">Cerrar Sesion</a>
        </div>
        <div class="col-1"></div>
    </div>
    
    <?= $this->renderSection('inicio') ?>

    <?= $this->renderSection('libros') ?>

    <?= $this->renderSection('opcion_gestion_libro') ?>

    <?= $this->renderSection('agregar_libro') ?>

    <?= $this->renderSection('opcion_gestion_usuario') ?>
    
    <?= $this->renderSection('agregar_profesor') ?>

    <?= $this->renderSection('agregar_estudiante') ?>

    <?= $this->renderSection('agregar_pas') ?>

    <?= $this->renderSection('mi_cuenta_usuario') ?>
    
    <?= $this->renderSection('pagina_registrar') ?>

    <?= $this->renderSection('tipo_usuario') ?>

    <?= $this->renderSection('opcion_gestion_ejemplar') ?>

    <?= $this->renderSection('reservas') ?>

    <?= $this->renderSection('editar_biblioteca') ?>

</body>
</html>