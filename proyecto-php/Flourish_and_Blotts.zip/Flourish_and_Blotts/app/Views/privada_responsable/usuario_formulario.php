<?= $this->extend('layouts/privado_responsable') ?>

<?= $this->section('usuario_formulario') ?>

    <div class="container">
        <div class="row" style="margin-top: 20px;">
            <div class="col"></div>
            <div class="col" style="text-align: center;"><h2>Agregar usuario</h2></div>
            <div class="col"></div>
        </div>
        <div class="row" style="margin-top: 20px;">
            <div class="col"></div>
            <div class="col">
                <div class="mb-3">
                    <label for="exampleFormControlInput1" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Example textarea</label>
                    <input class="form-control" id="exampleFormControlTextarea1" rows="3">
                </div>
            </div>
            <div class="col"></div>
        </div>
    </div>


<?= $this->endSection() ?>