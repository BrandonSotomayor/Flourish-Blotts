<?= $this->extend('layouts/privado_responsable') ?>

<?= $this->section('inicio') ?>

    <div class="container">
        <div class="row" style="margin-top: 20px;">
            <div class="col-2"></div>
            <div class="col-8">
                <div class="row" style="text-align: center;"><h4>Editar parte pública</h4></div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td><a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/editar_biblioteca') ?>" class="btn-light">Datos biblioteca</a></td>
                            </tr>
                        </tbody>
                    </table>
            </div>
            <div class="col-10"></div>
        </div>
    </div>


<?= $this->endSection() ?>