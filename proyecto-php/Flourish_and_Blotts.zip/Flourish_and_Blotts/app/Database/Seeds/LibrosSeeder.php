<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class LibrosSeeder extends Seeder
{
    public function run()
    {
        $data = [
            'isbn_13' => '1234567891234',
            'titulo' => 'Prisionero de Askaban',
            'subtitulo' => 'Azkaban',
            'idioma' => 'Inglés',
            'editorial' => 'Bloomsbury',
            'fecha_publicacion' => '1999-02-12',
            'numero_paginas' => '435',
            'descripcion' => 'El prisionero de Azkaban narra los hechos que suceden a lo largo del tercer curso de su protagonista, Harry Potter, en el Colegio Hogwarts. Aunque en la novela no aparece el antagonista de la serie, lord Voldemort, la trama presenta una nueva situación de riesgo para el personaje central: Sirius Black, uno de los asesinos de Voldemort, se fuga de la prisión de Azkaban para asesinar a Harry y dejar el camino libre para el regreso de su amo al poder. Las autoridades de la comunidad mágica reaccionan ante la noticia cercando el colegio y otros lugares de su jurisdicción con los dementores, criaturas tenebrosas que ofician de carceleros en Azkaban.',
            'imagen' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYZp5NOl0Y7UOXW978kskk7UtxMh_Td110vQ&usqp=CAU'
        ];
        $this->db->table('libros')->insert($data);


        $data = [
            'nombre_autor' => 'J. K. Rowling'
        ];
        $this->db->table('autores')->insert($data);


        $data = [
            'id_libro' => 'J. K. Rowling'
        ];
        $this->db->table('autores')->insert($data);


        $data = [
            'isbn_13' => '1234567891234',
            'titulo' => 'Prisionero de Askaban',
            'subtitulo' => 'Azkaban',
            'idioma' => 'Inglés',
            'editorial' => 'Bloomsbury',
            'fecha_publicacion' => '1999-02-12',
            'numero_paginas' => '435',
            'descripcion' => 'El prisionero de Azkaban narra los hechos que suceden a lo largo del tercer curso de su protagonista, Harry Potter, en el Colegio Hogwarts. Aunque en la novela no aparece el antagonista de la serie, lord Voldemort, la trama presenta una nueva situación de riesgo para el personaje central: Sirius Black, uno de los asesinos de Voldemort, se fuga de la prisión de Azkaban para asesinar a Harry y dejar el camino libre para el regreso de su amo al poder. Las autoridades de la comunidad mágica reaccionan ante la noticia cercando el colegio y otros lugares de su jurisdicción con los dementores, criaturas tenebrosas que ofician de carceleros en Azkaban.',
            'imagen' => 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYZp5NOl0Y7UOXW978kskk7UtxMh_Td110vQ&usqp=CAU'
        ];
        $this->db->table('libros')->insert($data);
    }
}
