<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
//$routes->setDefaultController('Home');
//$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
//$routes->get('/', 'Home::index');
$routes->get('/', 'GeneralController::pagina_principal');
$routes->group("publica", function ($routes) {

    $routes->get('inicio', 'GeneralController::pagina_principal');
    $routes->get('catalogo', 'GeneralController::catalogo');
    $routes->get('horarios', 'GeneralController::horarios');

    $routes->group("catalogo", function ($routes) {

        $routes->get('busqueda_simple', 'GeneralController::busqueda_simple');
        
        $routes->get('busqueda_avanzada', 'GeneralController::busqueda_avanzada');
        $routes->post('busqueda_avanzada', 'GeneralController::busqueda_avanzada');
    });

});

$routes->group("usuarios", function ($routes) {


    $routes->get('cerrar_sesion', 'UsuariosController::cerrar_sesion');
    $routes->get('iniciar_sesion', 'UsuariosController::iniciar_sesion');
    $routes->post('iniciar_sesion',"UsuariosController::iniciar_sesion_post");

    //TODAS LAS PÁGINAS DE INICIO DE LOS USUARIOS, SOLO HACE FALTA PONER LA RUTA (usuarios/privado/id_rol)
    $routes->get('privado/(:segment)', 'UsuariosController::parte_privada/$1', ['filter'=>'Autentica']);

    $routes->group('privado/1',['filter'=>'Autentica'],function($routes){

        $routes->get('gestion_responsable',"UsuariosController::gestion_responsable");
        $routes->get('agregar_responsable',"UsuariosController::agregar_responsable");
        $routes->post('agregar_responsable',"UsuariosController::agregar_usuario_post");
        $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");
        $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
        $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_usuario_post");

        //LIBROS
        $routes->get('gestion_libros',"UsuariosController::gestion_libros");
        $routes->get('agregar_libro',"UsuariosController::agregar_libro");
        $routes->post('agregar_libro',"UsuariosController::agregar_libro_post");
        $routes->get('borrar_libro','LibrosController::borrar_libro');

    });

    //ACCIONES DEL RESPONSABLE
    $routes->group('privado/2',['filter'=>'Autentica'],function($routes){
        //$routes->get('inicio',"UsuariosController::inicio");
        
        $routes->get('editar_biblioteca',"UsuariosController::editar_biblioteca");
        $routes->post('editar_biblioteca',"UsuariosController::editar_biblioteca_post");

        //LIBROS
        $routes->get('gestion_libros',"UsuariosController::gestion_libros");
        $routes->get('agregar_libro',"UsuariosController::agregar_libro");
        $routes->post('agregar_libro',"UsuariosController::agregar_libro_post");
        $routes->get('borrar_libro','LibrosController::borrar_libro');


        //EJEMPLARES
        $routes->get('gestion_ejemplares',"LibrosController::gestion_ejemplares");
        $routes->get('agregar_ejemplar',"LibrosController::agregar_ejemplar");
        $routes->get('borrar_ejemplar','LibrosController::borrar_ejemplar');


        //USUARIOS
        $routes->get('gestion_usuarios',"UsuariosController::gestion_usuarios");
        $routes->get('agregar_profesor',"UsuariosController::agregar_profesor");
        $routes->post('agregar_profesor',"UsuariosController::agregar_usuario_post");
        $routes->get('agregar_estudiante',"UsuariosController::agregar_estudiante");
        $routes->post('agregar_estudiante',"UsuariosController::agregar_usuario_post");
        $routes->get('agregar_pas',"UsuariosController::agregar_pas");
        $routes->post('agregar_pas',"UsuariosController::agregar_usuario_post");
        $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");

        $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
        $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_usuario_post");

        $routes->get('usuario_masivo',"UploadFilesController::usuario_masivo");
        $routes->post('file/upload',"UploadFilesController::upload");
        $routes->post('usuario_masivo',"UploadFilesController::upload");

        //RESERVAS
        $routes->get('reservas',"LibrosController::reservas");
        $routes->post('reserva_aceptada',"LibrosController::reserva_aceptada");


    });

    //PROFESOR
    $routes->group('privado/3',['filter'=>'Autentica'],function($routes){
        $routes->get('inicio',"UsuariosController::inicio");

        $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
        $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_profesor_post");

        $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");

        $routes->get('catalogo',"UsuariosController::catalogo");

        $routes->get('reservar',"LibrosController::reservar");

        $routes->get('recogido',"LibrosController::recogido");

        $routes->get('historial_reservas',"LibrosController::historial_reservas");

        $routes->get('formulario_opinion',"LibrosController::formulario_opinion");

        $routes->post('opinar',"LibrosController::opinar");

        $routes->get('devolver',"LibrosController::devolver");

    });

    //ESTUDIANTE
    $routes->group('privado/4',['filter'=>'Autentica'],function($routes){
        $routes->get('inicio',"UsuariosController::inicio");

        $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
        $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_estudiante_post");

        $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");

        $routes->get('catalogo',"UsuariosController::catalogo");

        $routes->get('reservar',"LibrosController::reservar");

        $routes->get('recogido',"LibrosController::recogido");

        $routes->get('historial_reservas',"LibrosController::historial_reservas");

        $routes->get('formulario_opinion',"LibrosController::formulario_opinion");

        $routes->post('opinar',"LibrosController::opinar");

    });

    //PAS
    $routes->group('privado/5',['filter'=>'Autentica'],function($routes){
        $routes->get('inicio',"UsuariosController::inicio");

        $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
        $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_usuario_post");

        $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");

        $routes->get('catalogo',"UsuariosController::catalogo");

        $routes->get('reservar',"LibrosController::reservar");

        $routes->get('recogido',"LibrosController::recogido");

        $routes->get('historial_reservas',"LibrosController::historial_reservas");

        $routes->get('formulario_opinion',"LibrosController::formulario_opinion");

        $routes->post('opinar',"LibrosController::opinar");

    });

    $routes->get('privado/(:segment)','UsuariosController::pagina_privada/$1');
    $routes->get('privado/(:segment)/libros','UsuariosController::gestion_libros/$1');

});


$routes->group("api", function ($routes) {

    $routes->group("publica", function ($routes) {

        $routes->options("inicio", "ApiPublicaController::inicio");
        $routes->get('inicio', 'ApiPublicaController::inicio');
        //$routes->get('catalogo', 'GeneralController::catalogo');
        
        $routes->options("horarios", "ApiPublicaController::horarios");
        $routes->get('horarios', 'ApiPublicaController::horarios');
    
        $routes->group("catalogo", function ($routes) {
    
            $routes->get('busqueda_simple', 'ApiPublicaController::busqueda_simple');
            //$routes->get('busqueda_avanzada', 'GeneralController::busqueda_avanzada');

            $routes->options("busqueda_avanzada", "ApiPublicaController::busqueda_avanzada");
            $routes->post('busqueda_avanzada', 'ApiPublicaController::busqueda_avanzada');
        });
    
    });

    //INICIAR SESION 
    $routes->options("iniciar_sesion", "ApiPublicaController::iniciar_sesion");
    $routes->post("iniciar_sesion", "ApiPublicaController::iniciar_sesion");

    $routes->get('test', 'ApiPublicaController::test',['filter'=>'jwt']);
    $routes->group("test",['filter'=>'jwt'], function ($routes) {

        $routes->options("inicio", "ApiPublicaController::inicio");
        $routes->get("inicio", "ApiPublicaController::inicio");

        $routes->group("usuarios", function ($routes) {
        
            $routes->group('privado/1',function($routes){
                
                $routes->get('agregar_responsable',"ApiUsuarioAdministradorController::agregar_responsable_post");
                $routes->get('activar_desactivar',"ApiUsuarioAdministradorController::activar_desactivar");
                $routes->post('mi_cuenta_administrador',"ApiUsuarioAdministradorController::mi_cuenta_administrador_post");
        
            });
        
            //ACCIONES DEL RESPONSABLE
            $routes->group('privado/2',['filter'=>'Autentica'],function($routes){
                
                //$routes->get('editar_biblioteca',"UsuariosController::editar_biblioteca");
                $routes->post('editar_biblioteca',"ApiUsuarioResponsableController::editar_biblioteca_post");
        
                //LIBROS
                $routes->get('gestion_libros',"UsuariosController::gestion_libros");
                $routes->get('agregar_libro',"UsuariosController::agregar_libro");
                $routes->post('agregar_libro',"UsuariosController::agregar_libro_post");
                $routes->get('borrar_libro','LibrosController::borrar_libro');
        
        
                //EJEMPLARES
                $routes->get('gestion_ejemplares',"LibrosController::gestion_ejemplares");
                $routes->get('agregar_ejemplar',"LibrosController::agregar_ejemplar");
                $routes->get('borrar_ejemplar','LibrosController::borrar_ejemplar');
        
        
                //USUARIOS
                $routes->get('gestion_usuarios',"UsuariosController::gestion_usuarios");
                $routes->get('agregar_profesor',"UsuariosController::agregar_profesor");
                $routes->post('agregar_profesor',"UsuariosController::agregar_usuario_post");
                $routes->get('agregar_estudiante',"UsuariosController::agregar_estudiante");
                $routes->post('agregar_estudiante',"UsuariosController::agregar_usuario_post");
                $routes->get('agregar_pas',"UsuariosController::agregar_pas");
                $routes->post('agregar_pas',"UsuariosController::agregar_usuario_post");
                $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");
        
                $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
                $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_usuario_post");
        
                $routes->get('usuario_masivo',"UploadFilesController::usuario_masivo");
                $routes->post('file/upload',"UploadFilesController::upload");
                $routes->post('usuario_masivo',"UploadFilesController::upload");
        
                //RESERVAS
                $routes->get('reservas',"LibrosController::reservas");
                $routes->post('reserva_aceptada',"LibrosController::reserva_aceptada");
        
        
            });
        
            //PROFESOR
            $routes->group('privado/3',['filter'=>'Autentica'],function($routes){
                $routes->get('inicio',"UsuariosController::inicio");
        
                $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
                $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_profesor_post");
        
                $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");
        
                $routes->get('catalogo',"UsuariosController::catalogo");
        
                $routes->get('reservar',"LibrosController::reservar");
        
                $routes->get('recogido',"LibrosController::recogido");
        
                $routes->get('historial_reservas',"LibrosController::historial_reservas");
        
                $routes->get('formulario_opinion',"LibrosController::formulario_opinion");
        
                $routes->post('opinar',"LibrosController::opinar");
        
                $routes->get('devolver',"LibrosController::devolver");
        
            });
        
            //ESTUDIANTE
            $routes->group('privado/4',['filter'=>'Autentica'],function($routes){
                $routes->get('inicio',"UsuariosController::inicio");
        
                $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
                $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_estudiante_post");
        
                $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");
        
                $routes->get('catalogo',"UsuariosController::catalogo");
        
                $routes->get('reservar',"LibrosController::reservar");
        
                $routes->get('recogido',"LibrosController::recogido");
        
                $routes->get('historial_reservas',"LibrosController::historial_reservas");
        
                $routes->get('formulario_opinion',"LibrosController::formulario_opinion");
        
                $routes->post('opinar',"LibrosController::opinar");
        
            });
        
            //PAS
            $routes->group('privado/5',['filter'=>'Autentica'],function($routes){
                $routes->get('inicio',"UsuariosController::inicio");
        
                $routes->get('mi_cuenta',"UsuariosController::mi_cuenta");
                $routes->post('mi_cuenta',"UsuariosController::mi_cuenta_usuario_post");
        
                $routes->get('activar_desactivar',"UsuariosController::activar_desactivar");
        
                $routes->get('catalogo',"UsuariosController::catalogo");
        
                $routes->get('reservar',"LibrosController::reservar");
        
                $routes->get('recogido',"LibrosController::recogido");
        
                $routes->get('historial_reservas',"LibrosController::historial_reservas");
        
                $routes->get('formulario_opinion',"LibrosController::formulario_opinion");
        
                $routes->post('opinar',"LibrosController::opinar");
        
            });
        
            $routes->get('privado/(:segment)','UsuariosController::pagina_privada/$1');
            $routes->get('privado/(:segment)/libros','UsuariosController::gestion_libros/$1');
        
        });

    });

    $routes->options("agregar_usuario", "ApiPublicaController::agregar_usuario");
    $routes->post("agregar_usuario", "ApiPublicaController::agregar_usuario");
    
    
});

$routes->get('home', 'Home::index');
$routes->get('pruebas', 'Home::or');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
