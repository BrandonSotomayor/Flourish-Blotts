<?php

namespace App\Models;

use CodeIgniter\Model;

class EjemplaresModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'ejemplares';
    protected $primaryKey       = 'id_ejemplar';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['id_libro','id_ejemplar'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function busqueda_avanzada($titulo,$autor,$categoria){
        $db      = \Config\Database::connect();
        $builder = $db->table('ejemplares');
        
        $builder->select('*');
        $builder->join('libros', 'libros.id_libro = ejemplares.id_libro');
        $builder->join('libro_autor', 'libro_autor.id_libro = libros.id_libro');
        $builder->join('autores', 'autores.id_autor = libro_autor.id_autor');
        $builder->join('libro_categoria', 'libro_categoria.id_libro = libros.id_libro');
        $builder->join('categorias', 'categorias.id_categoria = libro_categoria.id_categoria');
        $query = $builder->getWhere(['autores.nombre_autor'=>$autor,'libros.titulo'=>$titulo]);
        return $query;
        
    }

    public function obtener_ejemplar($id_ejemplar=null){
        if ( $id_ejemplar != null ) return $this->where('id_ejemplar',$id_ejemplar);

        return $this->findAll();
    }
    public function borrar_ejemplar($id_ejemplar){
        
        return $this->where('id_ejemplar',$id_ejemplar)->delete();
    }
    
}
