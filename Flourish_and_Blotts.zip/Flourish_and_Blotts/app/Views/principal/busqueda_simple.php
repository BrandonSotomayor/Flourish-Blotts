<?= $this->extend('layouts/principal') ?>

<?= $this->section('news_boot_css') ?>
<style type="text/css">
    a {
        padding-left: 5px;
        padding-right: 5px;
        margin-left: 5px;
        margin-right: 5px;
    }

    .pagination li.active {
        background: deepskyblue;
        color: white;
    }

    .pagination li.active a {
        color: white;
        text-decoration: none;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('busqueda_simple') ?>

    <div class="container-fluid">
        <div class="container">
            <form action="<?= base_url('publica/busqueda_simple') ?>" method="GET" id="busqueda_simple">
                <div class="row" style="margin-top: 20px;">
                    <h3>Busqueda Simple</h3>
                </div>
                <div class="row" style="margin-top: 20px;">
                    <div class="col"><h5>Título</h5></div>
                    <div class="col-4"><input type="text" class="form-control" id='titulo' name="titulo" value="<?= $titulo ?>"></div>
                    <div class="col-1"><input type="submit" class="btn btn-dark" value="Buscar" onclick='document.getElementById("busqueda_simple").submit();'></div>
                    <div class="col-6"></div>
                </div> 
            </form>

            
            <!-- Search form -->
            <form method='get' action="<?= base_url('publica/busqueda_simple'); ?>" id="busqueda_simple">
                <input type='text' name='titulo' value='<?= $titulo ?>' placeholder="Search here...">
                <input type='button' id='btnsearch' value='Cercar' onclick='document.getElementById("searchForm").submit();'>
            </form>
            <br />

            <table class="table table-hover" style='border-collapse: collapse;'>
                <thead>
        <tr>
            
            <th>Title</th>
            <th>Text</th>
        </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($libros as $n) {
                        echo "<tr>";
                        echo "<td>" . $n['id_libro'] . "</td>";
                        echo "<td>" . $n['titulo'] . "</td>";
                        echo "<td>" . $n['descripcion'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>

            <?php   // TABLE GENERATED WITH TABLE-GEN-HELPER
            $template = [
                'table_open' => "<table class='table table-hover' style='border-collapse: collapse;'>"
            ];
            $table->setTemplate($template);
            $table->setHeading('Identificador', 'Título','Descripción');
            echo $table->generate($libros);
            ?>
            

        </div>
        </div>
    </div>


<?= $this->endSection() ?>