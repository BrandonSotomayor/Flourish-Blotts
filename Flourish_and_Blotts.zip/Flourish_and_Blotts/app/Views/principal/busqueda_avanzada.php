<?= $this->extend('layouts/principal') ?>

<?= $this->section('catalogo') ?>

    <div class="container-fluid">

        <div class="container">
            <div class="row">
                <h2>Busqueda Avanzada</h2>
            </div>
            <form action="<?= base_url('publica/catalogo/busqueda_avanzada') ?>">
                <div class="row" style="margin-top: 10px;">
                    <div class="col-1"><h5>Autor</h5></div>
                    <div class="col-4"><input class="form-control" id="autor" name="autor"></div>
                    <div class="col-6"></div>
                </div>
                <div class="row" style="margin-top: 10px;">
                    <div class="col-1"><h5>Titulo*</h5></div>
                    <div class="col-4"><input class="form-control" id="titulo" name="titulo"></div>
                    <div class="col-6"></div>
                </div>
                <div class="row" style="margin-top: 10px;">
                    <div class="col-1"><h5>Categoria</h5></div>
                    <div class="col-4" style="margin-left: 2px;"><input class="form-control" id="categoria" name="categoria"></div>
                    <div class="col-1"><input type="submit" class="btn btn-secondary" value="Buscar"></div>
                </div>
            </form>

            <div class="row">
                <div class="col">
                    <div class="row" style="margin-top: 30px;">
                        <?php if (! empty($ejemplares) && is_array($ejemplares)): ?>
                                
                            <?php foreach ($ejemplares as $ejemplar): ?>

                        
                                <?php if ( $ejemplar['id_libro'] == $libro['id_libro'] && $libro_autor['id_autor'] == $autor['id_autor']  ){ ?> 
                                    <div class="row" style="margin-top: 30px;"> 
                                        <div class="col-2"></div>
                                        <div class="col-3" style="margin-top: 60px;">
                                            <img src="<?= $libro['imagen'] ?>" style="margin-top: 30px;">
                                        </div>
                                        <div class="col-5">
                                            <ul class="list-group">
                                                            <li class="list-group-item"><b>ISBN-13: </b><?= $libro['isbn_13'] ?></li>
                                                            <?php if ( $ejemplar['id_ejemplar'] < 10 ){ ?><li class="list-group-item"><b>QR: </b><?= $libro['isbn_13'] ?>-0<?= $ejemplar['id_ejemplar']?></li><?php } ?>
                                                            <?php if ( $ejemplar['id_ejemplar'] > 9 ){ ?><li class="list-group-item"><b>QR: </b><?= $libro['isbn_13'] ?>-<?= $ejemplar['id_ejemplar']?></li><?php } ?>
                                                            <li class="list-group-item"><b>Título: </b><?= $libro['titulo'] ?></li>
                                                            <li class="list-group-item"><b>Subtítulo: </b><?= $libro['subtitulo'] ?></li>
                                                            <li class="list-group-item"><b>Idioma: </b><?= $libro['idioma'] ?></li>
                                                            <li class="list-group-item"><b>Editorial: </b><?= $libro['editorial'] ?></li>
                                                            <li class="list-group-item"><b>Fecha publicación: </b><?= $libro['fecha_publicacion'] ?></li>
                                                            <li class="list-group-item"><b>Número de páginas: </b><?= $libro['numero_paginas'] ?></li>
                                                            <li class="list-group-item"><b>Descripción: </b><?= substr($libro['descripcion'], 0, -340 )."..." ?></li>
                                                        </ul>
                                        </div>
                                <?php } ?>
                                </tbody>
                            <?php endforeach ?>
                        <?php endif ?>
                                    </div>
                    </div>
                        <?php if (! empty($ejemplares) ): ?>
                        <?php foreach ($ejemplares->getResult() as $ejemplar): ?>
                            <div class="row" style="margin-top: 30px;"> 
                                <div class="col-2"></div>
                                <div class="col-3" style="margin-top: 60px;">
                                    <img src="<?= $ejemplar->imagen ?>" style="margin-top: 30px;">
                                </div>
                                <div class="col-5">
                                    <ul class="list-group">
                                        <li class="list-group-item"><b>ISBN-13: </b><?= $ejemplar->isbn_13 ?></li>
                                        <?php if ( $ejemplar->id_ejemplar < 10 ){ ?><li class="list-group-item"><b>QR: </b><?= $ejemplar->isbn_13 ?>-0<?= $ejemplar->id_ejemplar ?></li><?php } ?>
                                        <?php if ( $ejemplar->id_ejemplar > 9 ){ ?><li class="list-group-item"><b>QR: </b><?= $ejemplar->isbn_13 ?>-<?= $ejemplar->id_ejemplar ?></li><?php } ?>
                                        <li class="list-group-item"><b>Título: </b><?= $ejemplar->titulo ?></li>
                                        <li class="list-group-item"><b>Subtítulo: </b><?= $ejemplar->subtitulo ?></li>
                                        <li class="list-group-item"><b>Idioma: </b><?= $ejemplar->idioma ?></li>
                                        <li class="list-group-item"><b>Editorial: </b><?= $ejemplar->editorial ?></li>
                                        <li class="list-group-item"><b>Fecha publicación: </b><?= $ejemplar->fecha_publicacion ?></li>
                                        <li class="list-group-item"><b>Número de páginas: </b><?= $ejemplar->numero_paginas ?></li>
                                        <li class="list-group-item"><b>Descripción: </b><?= substr($ejemplar->descripcion, 0, -340 )."..." ?></li>
                                    </ul>
                                </div>
                            </div>
                        <?php endforeach ?>
                        <?php endif ?>
            </div>
        </div>
    </div>


<?= $this->endSection() ?>

miborrar4inscaparrella.cat