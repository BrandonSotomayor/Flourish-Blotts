<?= $this->extend('layouts/privado_usuario') ?>

<?= $this->section('formulario_opinion') ?>

    <div class="container">
        <div class="row" style="margin-top: 20px;">
            <div class="col"></div>
            <div class="col" style="text-align: center;">
                <h2>Opinión de <?= $libros['titulo'] ?></h2>
                <form action="<?= base_url('usuarios/privado/'.session()->get('rol').'/opinar') ?>" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" id="id_libro" name="id_libro" value="<?= $libros['id_libro'] ?>">                    

                    <div class="row" style="margin-top: 20px;">
                        <textarea id="opinion" name="opinion" style="height: 150px;width:100%" class="form-control"></textarea>
                    </div>
                    <div class="row" style="margin-top: 20px;">
                        <div class="col"></div>
                        <div class="col"><input type="submit" class="btn btn-light" value="Enviar"></div>
                        <div class="col"><a href="<?= base_url('usuarios/privado/'.session()->get('rol')) ?>" class="btn btn-dark">Cancelar</a></div>
                        <div class="col"></div>
                    </div>
                </form>
            </div>
            <div class="col"></div>
        </div>
    </div>


<?= $this->endSection() ?>