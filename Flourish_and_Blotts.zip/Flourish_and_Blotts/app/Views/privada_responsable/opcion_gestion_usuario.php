<?= $this->extend('layouts/privado_responsable') ?>

<?= $this->section('opcion_gestion_usuario') ?>

    <div class="container">
        <div class="row" style="margin-top: 20px;text-align:center">
            <h5 style="background-color:#C6E7E6;"><?= session()->getFlashdata('mensaje') ?></h5>
            <h2>Gestión de usuarios</h2>
        </div>
        <div class="row" style="margin-top: 20px;">
            <div class="col"></div>
            <div class="col-6" style="text-align: center;">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Gestión Masiva</th>
                            <th scope="col">Gestión Individual</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><a href="<?= base_url('usuarios/privado/2/usuario_masivo') ?>" class="btn btn-light">Profesores</a></td>
                            <td><a href="<?= base_url('usuarios/privado/2/agregar_profesor') ?>" class="btn btn-light">Profesor</a></td>
                        </tr>
                        <tr>
                            <td><a href="<?= base_url('usuarios/privado/2/usuario_masivo') ?>" class="btn btn-light">Estudiantes</a></td>
                            <td><a href="<?= base_url('usuarios/privado/2/agregar_estudiante') ?>" class="btn btn-light">Estudiante</a></td>
                        </tr>
                        <tr>
                        <td><a href="<?= base_url('usuarios/privado/2/usuario_masivo') ?>" class="btn btn-light">PAS</a></td>
                            <td><a href="<?= base_url('usuarios/privado/2/agregar_pas') ?>" class="btn btn-light">PAS</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="col"></div>
        </div>
        <div class="row" style="text-align: center;">
            <h3>Usuarios</h3>
            <div class="col"></div>
            <div class="col-10">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">DNI/NIE</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Apellido 1</th>
                            <th scope="col">Apellido 2</th>
                            <th scope="col">Correo electrónico</th>
                            <th scope="col">Rol</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Penalización</th>
                            <th></th>
                        </tr>
                    </thead>

                    <?php if (! empty($usuarios) && is_array($usuarios)): ?>
                        
                        <?php foreach ($usuarios as $usuario): ?>

                            <tbody>
                                <tr>
                                    <td><?= $usuario['dni_nie']?></td>
                                    <td><?= $usuario['nombre']?></td>
                                    <td><?= $usuario['apellido1']?></td>
                                    <td><?= $usuario['apellido2']?></td>
                                    <td><?= $usuario['correo_electronico']?></td>
                                    <?php foreach ( $roles as $rol ): 
                                        if ( $rol['id_rol'] == $usuario['id_rol'] && $rol['nombre_rol'] != 'responsable' && $rol['nombre_rol'] != 'administrador' ) {?>
                                            <td><?= $rol['nombre_rol'] ?></td>
                                            <td><?= $usuario['estado']?></td>
                                            <?php if ($usuario['id_penalizacion'] == null ){?><td>No</td><?php } ?>
                                            <?php if ($usuario['id_penalizacion'] != null ){?><td>Si</td><?php } ?>
                                            <?php if ($usuario['estado'] == 'activo' ){?><td><a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/activar_desactivar').'?id_usuario='.$usuario['id_usuario'].'&estado='.$usuario['estado'] ?>" class="btn btn-secondary">Desactivar</a></td><?php } ?>
                                            <?php if ($usuario['estado'] == 'desactivado' ){?><td><a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/activar_desactivar').'?id_usuario='.$usuario['id_usuario'].'&estado='.$usuario['estado'] ?>" class="btn btn-light">Activar</a></td><?php } ?>
                                        <?php }
                                        elseif ( $rol['id_rol'] == $usuario['id_rol'] && $rol['nombre_rol'] == 'responsable' ){ ?>
                                            <td><?= $rol['nombre_rol'] ?></td>
                                        <?php } 
                                        elseif ( $rol['id_rol'] == $usuario['id_rol'] && $rol['nombre_rol'] == 'administrador' ){ ?>
                                            <td><?= $rol['nombre_rol'] ?></td>
                                        <?php } 
                                    endforeach ?>
                                </tr>
                            </tbody>
                        <?php endforeach ?>
                </table>
                    <?php endif ?>
            </div>
            <div class="col"></div>
        </div>
    </div>


<?= $this->endSection() ?>