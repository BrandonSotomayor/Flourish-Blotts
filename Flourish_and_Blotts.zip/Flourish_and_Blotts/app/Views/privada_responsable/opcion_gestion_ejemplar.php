<?= $this->extend('layouts/privado_responsable') ?>

<?= $this->section('opcion_gestion_libro') ?>

    <div class="container">
        <div class="row" style="margin-top: 20px;">
            <div class="col"></div>
            <div class="col" style="text-align: center;"><h2>Gestión de ejemplares</h2></div>
            <div class="col"></div>
        </div>
        <div class="row" style="margin-top: 20px;">
            <div class="col"></div>
            <div class="col" style="text-align: center;">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><a href="<?= base_url('usuarios/privado/2/agregar_ejemplar') ?>" class="btn btn-light">Gestión Masiva</a></td>
                        </tr>
                    </tbody>
                </table></div>
            <div class="col"></div>
        </div>
        <div class="row" style="text-align: center;">
            <h3>Ejemplares</h3>
            <div class="col-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">ISBN-13</th>
                            <th scope="col">Título</th>
                            <th scope="col">QR</th>
                            <!--<th scope="col">Núm. Ejemplares</th>-->
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>

                    <?php if (! empty($libros) && is_array($libros)): ?>
                        
                        <?php foreach ($libros as $libro): ?>

                            <tbody>
                                <tr>
                                <?php if (! empty($ejemplares) && is_array($ejemplares)): ?>
                        
                                    <?php foreach ($ejemplares as $ejemplar): ?>

                                        <tbody>
                                            <tr>
                                                <td><?= $libro['isbn_13'] ?></td>
                                                <td><?= $libro['titulo'] ?></td>
                                                <?php if ( $libro['id_libro'] == $ejemplar['id_libro'] && $ejemplar['id_ejemplar'] < 10 ){ ?>
                                                    <td><?= $libro['isbn_13']."-0".$ejemplar['id_ejemplar'] ?></td>
                                                <?php } ?>
                                                <?php if ( $libro['id_libro'] == $ejemplar['id_libro'] && $ejemplar['id_ejemplar'] >= 10 ){ ?>
                                                    <td><?= $libro['isbn_13']."-".$ejemplar['id_ejemplar'] ?></td>
                                                <?php } ?>
                                                <td><td><a href="<?= base_url('usuarios/privado/2/agregar_ejemplar').'?id_libro='.$libro['id_libro'] ?>" class="btn btn-secondary">+</a></td></td>
                                                <td><a href="<?= base_url('usuarios/privado/2/borrar_ejemplar').'?id_ejemplar='.$ejemplar['id_ejemplar'] ?>" class="btn btn-secondary">Borrar</a></td>
                                            </tr>
                                        </tbody>
                                    <?php endforeach ?>
                            </table>
                                <?php endif ?>
                                </tr>
                            </tbody>
                        <?php endforeach ?>
                </table>
                    <?php endif ?>
            </div>
        </div>
    </div>


<?= $this->endSection() ?>