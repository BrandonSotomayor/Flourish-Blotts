<?= $this->extend('layouts/principal') ?>

<?= $this->section('agregar_usuario_masivo') ?>

    <div class="container">
        <div class="row">
            <div class="col"></div>
            <div class="col">
                <h2>CSV</h2>
                <?= form_open_multipart(base_url('usuarios/privado/'.session()->get('rol').'/usuario_masivo')) ?>
                    <input type="file" class="btn" name="userfile" size="20" />
                    <input type="submit" value="upload" />
                </form>
            </div>
            <div class="col"></div>
        </div>
        <div class="row">
        <h2><?= esc($title) ?></h2>

            <?php foreach ($errors as $error) : ?>
                <li><?= esc($error) ?></li>
            <?php endforeach ?>

            <div style='padding:25px'>
                <?= form_open_multipart(base_url('usuarios/privado/'.session()->get('rol').'/file/upload')) ?>
                    <input type="file" name="userfile" size="20" />
                    <input type="submit" value="upload" />
                </form>
            </div>
        </div>
    </div>

<?= $this->endSection() ?>