<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flourish & Blotts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>

    <div class="container-fluid">
        <div class="row bg-dark">
            <div class="col-1"></div>
            <div class="col bg-dark text-light"><h1>Flourish & Blotts</h1></div>
        </div>
    </div>
    <div class="row bg-secondary">
        <div class="col"></div>
        <div class="col-2"></div>
        <div class="col-2">
            <a href="<?= base_url('usuarios/privado/'.session()->get('rol').'/mi_cuenta').'?id_usuario='.session()->get('id_usuario') ?>" class="btn btn-secondary">Mi Cuenta</a>
            <a href="<?= base_url('usuarios/cerrar_sesion') ?>" class="btn btn-dark">Cerrar Sesion</a>
        </div>
        <div class="col-1"></div>
    </div>
    
    <?= $this->renderSection('gestion_responsable') ?>

    <?= $this->renderSection('agregar_resposable') ?>

    <?= $this->renderSection('mi_cuenta_usuario') ?>

</body>
</html>