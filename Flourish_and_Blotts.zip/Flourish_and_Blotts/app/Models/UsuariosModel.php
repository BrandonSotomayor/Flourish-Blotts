<?php

namespace App\Models;

use CodeIgniter\Model;

class UsuariosModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'usuarios';
    protected $primaryKey       = 'id_usuario';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['id_usuario','dni_nie','nombre','apellido1','apellido2','correo_electronico','contrasena','estado','id_rol','id_penalizacion'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function insertarUsuarios($dni_nie,$nombre,$apellido1,$apellido2,$correo_electronico,$contrasena,$estado,$id_rol,$id_penalizacion=null){
        $this->db->table('usuarios')->insert([
            'dni_nie' => $dni_nie,
            'nombre' => $nombre,
            'apellido1' => $apellido1,
            'apellido2' => $apellido2,
            'correo_electronico' => $correo_electronico,
            'contrasena' => password_hash($contrasena, PASSWORD_DEFAULT),
            'estado' => $estado,//"activo",
            'id_rol' => $id_rol,
            'id_penalizacion' => $id_penalizacion
        ]);
    }

    public function insertarProfesor($id_usuario,$tipo_profesor,$nombre_familia_profesional){
        $this->db->table('profesores')->insert([
            'id_usuario'=>$id_usuario,
            'tipo_profesor' => $tipo_profesor,
            'nombre_familia_profesional' => $nombre_familia_profesional
        ]);
    }

    public function insertarEstudiante($id_usuario,$nombre_estudio,$curso,$grupo){
        $this->db->table('estudiantes')->insert([
            'id_usuario'=>$id_usuario,
            'nombre_estudio' => $nombre_estudio,
            'curso' => $curso,
            'grupo' => $grupo
        ]);
    }

    public function obtener_usuario($id_usuario=null){
        if ( $id_usuario != null ) return $this->where('id_usuario',$id_usuario)->first();

        return $this->findAll();
    }

    public function getUserByMailOrUsername($correo_electronico) {
           
        if ( str_contains($correo_electronico,'@') ){
            return $this->where('correo_electronico',$correo_electronico)->first();
        }
        return $this->orWhere('nombre',$correo_electronico)->first();
    }

    public function conseguirtUsuarios(){
        return $this->findAll();
    }

    public function activar_desactivar($id_usuario,$data){
        
        //dd($id_usuario)
        return $this->update($id_usuario,$data);
    }

    public function actualizar_usuario($id_usuario,$data){
        return $this->update($id_usuario,$data);
    }

    public function obtener_responsables(){
        $db      = \Config\Database::connect();
        $builder = $db->table('usuarios');
        
        $builder->select('*');
        $builder->join('roles', 'roles.id_rol = usuarios.id_rol');
        $query = $builder->getWhere(['usuarios.id_rol'=>'2','roles.id_rol'=>'2']);
        
        /*foreach ( $query->getResult() as $row ){
            echo $row->nombre_rol." ";
        }
        dd($query);*/
        return $query;
    }

}
