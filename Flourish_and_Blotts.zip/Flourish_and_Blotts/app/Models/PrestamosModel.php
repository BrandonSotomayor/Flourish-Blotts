<?php

namespace App\Models;

use CodeIgniter\Model;

class PrestamosModel extends Model
{
    protected $DBGroup          = 'default';
    protected $table            = 'prestamos';
    protected $primaryKey       = 'id_prestamo';
    protected $useAutoIncrement = true;
    protected $insertID         = 0;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ['id_prestamo','id_ejemplar','id_usuario','fecha_inicio','fecha_devolucion'];

    // Dates
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules      = [];
    protected $validationMessages   = [];
    protected $skipValidation       = false;
    protected $cleanValidationRules = true;

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];

    public function insertar_prestamo($data){
        return $this->save($data);
    }

    public function obtener_prestamo($id_prestamo=null){
        if ( $id_prestamo != null ) return $this->where('id_prestamo',$id_prestamo);

        return $this->findAll();
    }

    public function actualizar_prestamo($id_prestamo,$data){
        return $this->update($id_prestamo,$data);
    }
}
