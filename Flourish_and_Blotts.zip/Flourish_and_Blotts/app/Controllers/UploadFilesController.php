<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use CodeIgniter\Files\File;

class UploadFilesController extends BaseController
{
    public function __construct()
    {
        helper('form');
    }

    public function usuario_masivo()
    {
        $data['title'] = "Single file uploader";
        $data['errors'] = [];

        return view('privada_responsable/agregar_usuario_masivo', $data);
    }

    public function upload()
    {
        $data['title'] = "Single file uploader";

        $validationRule = [
            'userfile' => [
                'label' => 'Image File',
                'rules' => 'uploaded[userfile]'
                    . '|is_image[userfile]'
                    . '|mime_in[userfile,image/jpg,image/jpeg,image/gif,image/png,image/webp]'
                    . '|max_size[userfile,100]'
                    . '|max_dims[userfile,1024,768]',
            ],
        ];
        if (!$this->validate($validationRule)) {
            $data['errors'] = $this->validator->getErrors();
            return view('privada_responsable/agregar_usuario_masivo', $data);
        }

        $img = $this->request->getFile('userfile');

        if (!$img->hasMoved()) {
            $filepath = WRITEPATH . 'uploads/' . $img->store();
            dd($filepath);

            $data['uploaded_flleinfo'] = new File($filepath);

            return view('privada_responsable/agregar_usuario_masivo_ok', $data);
        } else {
            $data['errors'] = 'The file has already been moved.';

            return view('privada_responsable/agregar_usuario_masivo', $data);
        }
    }
}
