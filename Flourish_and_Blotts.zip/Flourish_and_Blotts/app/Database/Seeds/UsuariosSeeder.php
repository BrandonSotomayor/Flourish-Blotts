<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UsuariosSeeder extends Seeder
{
    public function run()
    {
        $data = [
                'dni_nie' => '12-5523738',
                'nombre' => 'Filide',
                'apellido1' => 'Marchent',
                'apellido2' => 'Binney',
                'correo_electronico' => 'fbinney0@google.com.hk',
                'contrasena' => 'CFGS DAM',
                'estado' => 'activo',
                'id_rol' => 4,
                'id_penalizacion' => null
        ];
        $this->db->table('usuarios')->insert($data);

        /*$data = [
            'dni_nie' => '12-5548738',
            'nombre' => 'Filide',
            'apellido1' => 'Marchent',
            'apellido2' => 'Binney',
            'correo_electronico' => 'fbinney0@google.com.hk',
            'contrasena' => 'CFGS DAM',
            'estado' => 'activo',
            'id_rol' => 1,
            'id_penalizacion' => null
        ];
        $this->db->table('usuarios')->insert($data);*/
    }

    //SELECT dni_nie FROM usuarios inner join roles on usuarios.id_rol = roles.id_rol wHERE roles.id_rol=4
}
