
## TODO
- [ ] Add additional function/button for every item in table list
- [ ] Add command to install sample and controller sample to project


## DONE

- [x] Update callback to permit cancel post in edit or add callbacks @done (22-05-05 20:39)
- [x] Add inEditMode, inAdd... @done (22-05-10 19:16)
- [x] PASSWORD field type, only for edit or add pages. Edit page doesn't show db pass @done (22-05-06 15:55)
- [x] Add callback post edit @done (22-05-05 20:35)
- [x] Add callback post add @done (22-05-05 20:35)
- [x] Disable js/css header feature @done (22-05-05 19:15)
- [x] Add config class @done(22-04-7 12:36)
- [x] Add where clause to filter items before sending to view @done(22-04-12 12:30) .
- [x] Add list.todos and doc it @done(22-04-12 12:37) .
- [x] Modify setColumnsInfo function, to change field type
- [x] type email with validation
- [x] type checkbox
- [x] Modify setColumnsInfo function, to add html attributes: pattern, placeholder...
- [x] date field type
- [x] Textarea field
- [x] Check duplicateds when add item
- [x] Check field type is ok
- [x] Dropdown field, with data params: array or associative_array
- [x] Add Exceptions to readme.md
- [x] Add addWhere to readme.md


